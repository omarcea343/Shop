

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body onload="loadCookie()">
    <div id="menu">
        <ul>
            <li>Home</li>
            <li class="cerrar-sesion"><button type="button" id="bnr"><a href="includes/logout.php">cerrar sesion</a></button></li>
        </ul>
    </div>

    <section>
        <h1>Bienvenido <?php echo $user->getNombre();  ?></h1>
        <p id="ho">
            (os) It's Emmett, Clara. (Clara gets up from her desk and opens the door. She smiles at Doc.) Oh, Emmett, won't you come in? No...I better not. I... What's wrong?
        </p>
    </section>

    <script src="js/accesivilidad.js"></script>
    
</body>
</html>