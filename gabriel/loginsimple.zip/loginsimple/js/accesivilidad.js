document.getElementById("bby").addEventListener("click",by);
document.getElementById("bnr").addEventListener("click",nor);
document.getElementById("bbg").addEventListener("click",bg);


function verCookies(){
	alert("Cookies actuales:\n"+document.cookie);
}

function by(){        
	var estilo = "by";    
	setCookie(estilo);
    document.getElementById("ho").className = estilo;
}

function bg(){        
    var estilo = "bg";    
    setCookie(estilo);
    document.getElementById("ho").className = estilo;
}

function nor(){
    var estilo = "normal";    
    setCookie(estilo);
    document.getElementById("ho").className = estilo;
}

function setCookie(estilo) {
    var cookie = {};
    cookie.estilo = estilo;            
    var jsonString = JSON.stringify(cookie);

    var d = new Date();
    d.setTime(d.getTime() + (1 * 24 * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = "accessibilidadCookie=" + jsonString + ";" + expires + ";path=/";
}

function getCookie() {            
    var cookieString = getCookieValue("accessibilidadCookie");            
    if(cookieString == "") return "normal";
            
    var cookie = JSON.parse(cookieString);
    console.log(cookie);
    return cookie.estilo;
}
       
function getCookieValue(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function loadCookie() {            
    var estilo = getCookie();     
    document.getElementById("ho").className = estilo;       
}