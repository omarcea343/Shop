<?php
    function conexion(){
        return mysqli_connect('localhost',
                             'root',
                             '',
                             'graficos');
    }

    
?>

