<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Grafica</title>
    <link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
    <script src="librerias/jquery-3.4.1.min.js"></script>
    <script src="librerias/plotly-latest.min.js"></script>
</head>
<body>
   <div class="container">
       <div class="row">
           <div class="col-sm-12">
               <div class="oanel panel-primary">
                   <div class="panel panel-heading">GRAFICAS DE VENTAS DE CELULARES EN EL AÑO DEL 2017</div>
               </div>
               <div class="panel panel-body">
                   <div class="row">
                       <div class="col-sm-6">
                           <div id="cargaLineal"></div>
                       </div>
                       <div class="col-sm-6">
                           <div id="cargaBarras"></div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>
    
</body>
</html>


<script type="text/javascript">
    $(document).ready(function(){
        $('#cargaLineal').load('lineal.php');
        $('#cargaBarras').load('barras.php');
    });
</script>