<?php
    function conexion(){
        return mysqli_connect('localhost',
                             'root',
                             '',
                             'graf3');
    }

    
?>

