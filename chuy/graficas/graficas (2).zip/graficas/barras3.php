<?php
    require_once "php/conexion3.php";
    $conexion = conexion();
    $sql = "SELECT fechaVenta, montoVenta from ventas order by fechaVenta";
    $result = mysqli_query($conexion, $sql);
    $valoresY=array();//montos
    $valoresX=array();//fechas

    while ($ver=mysqli_fetch_row($result)){
        $valoresY[]=$ver[1];
        $valoresX[]=$ver[0];
    }

    $datosX=json_encode($valoresX);
    $datosY=json_encode($valoresY);

?>


<div id="graficaBarras3"></div>

<script type="text/javascript">
    function crearCadenaBarras(json){
        var parsed = JSON.parse(json);
        var arr = [];
        for(var x in parsed){
            arr.push(parsed[x]);
        }
        return arr;
    }
</script>

<script>
    
    datosX=crearCadenaBarras('<?php echo $datosX ?>');
    datosY=crearCadenaBarras('<?php echo $datosY ?>');
    
var data = [
  {
    x: datosX,
    y: datosY,
    type: 'bar'
  }
];
    
      var layout ={
        title: 'GAMA BAJA',
        font:{
            
            family: 'Arial'
        },
        xaxis: {
            title: 'MESES',
            tickangle: -45
        },
        yaxis: {
            title: 'VENTAS',
            zeroline: false,
            gridwidth: 2
        },
        bargap: 2
    };

Plotly.newPlot('graficaBarras3', data, layout);
</script>